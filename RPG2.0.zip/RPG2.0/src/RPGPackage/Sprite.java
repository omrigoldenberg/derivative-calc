package RPGPackage;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;

public abstract class Sprite {
	enum dir{
		RIGHT,LEFT,UP,DOWN,UPLEFT,UPRIGHT,DOWNRIGHT,DOWNLEFT;
	}
	int charX;
	int charY;
	int charXSize;
	int charYSize;
	BufferedImage charImg;
	File[] img;
	boolean attacking;
	public abstract void update();
	public abstract void draw(Graphics g);
}
