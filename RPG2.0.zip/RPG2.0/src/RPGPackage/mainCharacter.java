package RPGPackage;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.Timer;

public class mainCharacter extends Sprite implements ActionListener {
		int maxHealth;
		int maxMana;
		int currHealth;
		int currMana;
		int armor;
		int movementSpeed;
		int damage;
		boolean walking = false;
		dir look;
		boolean attacking = false;
		BufferedImage charImg;
		String name;
		int frameCounter;
		int charX;
		int charY;
		int charXSpeed;
		int charYSpeed;
		int charXSize;
		int charYSize;
		int charSpeed;
		File[] img = new File[32];
		Timer walk;
		Timer att;
		int attackCounter;
		static mainCharacter self = new mainCharacter("MC",500,500,50,50);
		mainCharacter(String name, int charX, int charY, int charXSize, int charYSize){
			maxHealth = 100;
			maxMana = 100;
			armor = 10;
			damage = 20;
			resetHealth();
			resetMana();
			this.charX =charX;
			this.charY = charY;
			this.charXSize = charXSize;
			this.charYSize = charYSize;
			frameCounter = 0;
			charXSpeed = 0;
			charYSpeed = 0;
			img[0] = new File("right1.png");
			img[1] = new File("right2.png");
			img[2] = new File("right3.png");
			img[3] = new File("right4.png");
			img[4] = new File("left1.png");
			img[5] = new File("left2.png");
			img[6] = new File("left3.png");
			img[7] = new File("left4.png");
			img[8] = new File("downLeft1.png");
			img[9] = new File("downLeft2.png");
			img[10] = new File("downLeft3.png");
			img[11] = new File("downLeft4.png");
			img[12] = new File("downRight1.png");
			img[13] = new File("downRight2.png");
			img[14] = new File("downRight3.png");
			img[15] = new File("downRight4.png");
			img[16] = new File("upRight1.png");
			img[17] = new File("upRight2.png");
			img[18] = new File("upRight3.png");
			img[19] = new File("upRight4.png");
			img[20] = new File("upLeft1.png");
			img[21] = new File("upLeft2.png");
			img[22] = new File("upLeft3.png");
			img[23] = new File("upLeft4.png");
			img[24] = new File("down1.png");
			img[25] = new File("down2.png");
			img[26] = new File("down3.png");
			img[27] = new File("down4.png");
			img[28] = new File("up1.png");
			img[29] = new File("up2.png");
			img[30] = new File("up3.png");
			img[31] = new File("up4.png");
			try {
				charImg = ImageIO.read(img[0]);
			} catch (IOException e1) 
			{
				System.out.println("nono");
			}
			charSpeed = 200;
			walk = new Timer (100, new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					currHealth-=1;
					if(look == dir.RIGHT) 
					{
						if(frameCounter<3)
							frameCounter++;
						else
							frameCounter = 0;
						try {
							charImg = ImageIO.read(img[frameCounter]);
						} catch (IOException e1) 
						{
							System.out.println("nono");
						}
					}
					if(look == dir.LEFT) 
					{
						if(frameCounter<3)
							frameCounter++;
						else
							frameCounter = 0;
						try {
							charImg = ImageIO.read(img[frameCounter+4]);
						} catch (IOException e1) 
						{
							System.out.println("nono");
						}
					}
					if(look == dir.DOWNLEFT) 
					{
						if(frameCounter<3)
							frameCounter++;
						else
							frameCounter = 0;
						try {
							charImg = ImageIO.read(img[frameCounter+8]);
						} catch (IOException e1) 
						{
							System.out.println("nono");
						}
					}
					if(look == dir.DOWNRIGHT) 
					{
						if(frameCounter<3)
							frameCounter++;
						else
							frameCounter = 0;
						try {
							charImg = ImageIO.read(img[frameCounter+12]);
						} catch (IOException e1) 
						{
							System.out.println("nono");
						}
					}
					if(look == dir.UPRIGHT) 
					{
						if(frameCounter<3)
							frameCounter++;
						else
							frameCounter = 0;
						try {
							charImg = ImageIO.read(img[frameCounter+16]);
						} catch (IOException e1) 
						{
							System.out.println("nono");
						}
					}
					if(look == dir.UPLEFT) 
					{
						if(frameCounter<3)
							frameCounter++;
						else
							frameCounter = 0;
						try {
							charImg = ImageIO.read(img[frameCounter+20]);
						} catch (IOException e1) 
						{
							System.out.println("nono");
						}
					}
					if(look == dir.DOWN) 
					{
						if(frameCounter<3)
							frameCounter++;
						else
							frameCounter = 0;
						try {
							charImg = ImageIO.read(img[frameCounter+24]);
						} catch (IOException e1) 
						{
							System.out.println("nono");
						}
					}
					if(look == dir.UP) 
					{
						if(frameCounter<3)
							frameCounter++;
						else
							frameCounter = 0;
						try {
							charImg = ImageIO.read(img[frameCounter+28]);
						} catch (IOException e1) 
						{
							System.out.println("nono");
						}
					}
				}
			});
		}
		public void resetHealth() {
			currHealth = maxHealth;
		}
		public void resetMana() {
			currMana = maxMana;
		}
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void update() {
			charX += (charXSpeed*(1.0/50));
			charY -= (charYSpeed*(1.0/50));	
		}
		@Override
		public void draw(Graphics g) {
			g.drawString("Health", 50, 885);
			g.drawString("Mana", 50, 925);
			g.setColor(Color.RED);
			g.fillRect(0, 890, (int)(200*((double)currHealth/maxHealth)), 20);
			g.setColor(Color.BLUE);
			g.fillRect(0, 930, (int)(200*((double)currMana/maxMana)), 20);
			g.setColor(Color.BLACK);
			g.drawImage(charImg, charX, charY ,charXSize,charYSize, null);
			
		}
		public void die() {
			// TODO Auto-generated method stub
			
		}
		public void takeDamage(int damage) {
			currHealth -= damage;
		}
		public static void main(String[] args) {
			mainCharacter mainChar = new mainCharacter("MC", 960, 850, 50, 50);
		}
}