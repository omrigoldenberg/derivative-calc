package RPGPackage;

import java.awt.Graphics;

public interface IState {
	String name = null;
	public void Update();
	public void Render(Graphics g);
	public void OnEnter();
	public void OnExit();
}
