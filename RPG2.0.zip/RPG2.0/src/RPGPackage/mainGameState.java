package RPGPackage;

import java.awt.Graphics;
import java.util.ArrayList;

public class mainGameState implements IState {
	
	ArrayList<Bound> bounds = new ArrayList<Bound>();
	Bound line = new Bound(0,100,1000,Bound.side.LEFT,Bound.orientation.HORIZONTAL);
	mainGameState(){
		bounds.add(line);
	}



	@Override
	public void Update() {
			mainCharacter.self.update();
			for(Bound x: bounds) 
			{
				if(x.collides(mainCharacter.self)&&x.o == Bound.orientation.HORIZONTAL&&x.s == Bound.side.LEFT)
					mainCharacter.self.charY = x.y + 5;
				if(x.collides(mainCharacter.self)&&x.o == Bound.orientation.HORIZONTAL&&x.s == Bound.side.RIGHT)
					mainCharacter.self.charY = x.y - 5;
				if(x.collides(mainCharacter.self)&&x.o == Bound.orientation.VERTICAL&& x.s == Bound.side.LEFT)
					mainCharacter.self.charX = x.x - 5;
				if(x.collides(mainCharacter.self)&&x.o == Bound.orientation.VERTICAL&& x.s == Bound.side.RIGHT)
					mainCharacter.self.charX = x.x - 5;
			}
	}
	@Override
	public void OnEnter() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void OnExit() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void Render(Graphics g) {
		mainCharacter.self.draw(g);
		g.drawLine(0, 100, 1000, 100);
	}

}
