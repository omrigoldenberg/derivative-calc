package RPGPackage;

public class Ability {
	String name;
	int manaCost;
	int damage;
	Ability(String name, int manaCost, int damage)
	{
		this.name = name;
		this.manaCost = manaCost;
		this.damage = damage;
	}
}
