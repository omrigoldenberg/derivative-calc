package RPGPackage;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Tile {
	int size = 50;
	BufferedImage img;
	int x;
	int y;
	Tile(File img){
		try {
			this.img = ImageIO.read(img);
		} catch (IOException e1) 
		{
		}
	}
	public void draw(Graphics g) {
		g.drawImage(img, x, y ,size,size, null);
	}
}
