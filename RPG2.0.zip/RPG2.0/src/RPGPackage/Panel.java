package RPGPackage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.Timer;
public class Panel extends JFrame implements ActionListener, KeyListener, MouseMotionListener{
	Timer mainTimer;
	mainCharacter mainChar;
	boolean a,s,d,w = false;
	canvas C;
	Panel(){
		mainChar = new mainCharacter("MC", 960, 850, 50, 50);
		C = new canvas();
		addKeyListener(this);
		addMouseMotionListener(this);
		setSize(1920,1080);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setTitle("RPG");
	    mainTimer = new Timer(20, new ActionListener()
	    {
	    	public void actionPerformed(ActionEvent e) {
	    		update();
	    	}
	    });
	    mainTimer.start();
	    createLevel();
	}
	public void createLevel() {
		add(C);
		
	}
	public void update() {
		C.update();
	}
	public static void main(String[] args) {
		Panel myPanel = new Panel();
		myPanel.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
	}
	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_A) {
			mainCharacter.self.charXSpeed = -mainCharacter.self.charSpeed;
			a = true;
			}
		if(e.getKeyCode() == KeyEvent.VK_D) {
			mainCharacter.self.charXSpeed = mainCharacter.self.charSpeed;
			d = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_W) {
			mainCharacter.self.charYSpeed = mainCharacter.self.charSpeed;
			w = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_S) {
			mainCharacter.self.charYSpeed = -mainCharacter.self.charSpeed;
			s = true;
			}
		if(e.getKeyCode() == KeyEvent.VK_I) {
			if(C.stack.get().equals("inventory"))
				C.stack.pop();
			else
				C.stack.push(C.inventory,"inventory");
			}
		if(a)
			mainCharacter.self.look = Sprite.dir.LEFT;
		if(d)
			mainCharacter.self.look = Sprite.dir.RIGHT;
		if(w)
			mainCharacter.self.look = Sprite.dir.UP;
		if(s)
			mainCharacter.self.look = Sprite.dir.DOWN;
		if(a&&w)
			mainCharacter.self.look = Sprite.dir.UPLEFT;
		if(d&&w)
			mainCharacter.self.look = Sprite.dir.UPRIGHT;
		if(a&&s)
			mainCharacter.self.look = Sprite.dir.DOWNLEFT;
		if(s&&d)
			mainCharacter.self.look = Sprite.dir.DOWNRIGHT;
		if(a||w||s||d) {
			mainCharacter.self.walk.start();
			mainCharacter.self.walking = true;
		}
	}
	@Override
	public void keyReleased(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_A) {
			mainCharacter.self.charXSpeed = 0;
			a = false;
		}
		if(e.getKeyCode() == KeyEvent.VK_D) {
			mainCharacter.self.charXSpeed = 0;
			d = false;
		}
		if(e.getKeyCode() == KeyEvent.VK_W) {
			mainCharacter.self.charYSpeed = 0;
			w = false;
		}
		if(e.getKeyCode() == KeyEvent.VK_S) {
			mainCharacter.self.charYSpeed = 0;
			s = false;
		}
		if(a)
			mainCharacter.self.look = Sprite.dir.LEFT;
		if(d)
			mainCharacter.self.look = Sprite.dir.RIGHT;
		if(w)
			mainCharacter.self.look = Sprite.dir.UP;
		if(s)
			mainCharacter.self.look = Sprite.dir.DOWN;
		if(a&&w)
			mainCharacter.self.look = Sprite.dir.UPLEFT;
		if(d&&w)
			mainCharacter.self.look = Sprite.dir.UPRIGHT;
		if(a&&s)
			mainCharacter.self.look = Sprite.dir.DOWNLEFT;
		if(s&&d)
			mainCharacter.self.look = Sprite.dir.DOWNRIGHT;
		if(!(a||w||s||d)) {
			mainCharacter.self.walk.stop();
			mainCharacter.self.walking = false;
		}
	}
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseDragged(MouseEvent e) {
	}
	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}