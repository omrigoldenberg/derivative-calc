package RPGPackage;

import java.awt.Rectangle;

public class Bound {

	int x;//if vetical top of bound, if horizontal leftmost point of bound
	int y;
	int length;
	enum side{
		LEFT,RIGHT
	}
	enum orientation{
		HORIZONTAL, VERTICAL;
	}
	side s;//shows whether the preferred boundary is to the left or right of the line
	orientation o;
	Bound(int x, int y, int length, side s, orientation o){
		this.x = x;
		this.y = y;
		this.length = length;
		this.s = s;
		this.o = o;
	}
	public boolean collides(mainCharacter mainChar)
		{
			Rectangle r2 = new Rectangle(mainChar.charX,mainChar.charY,mainChar.charXSize,mainChar.charYSize);
			Rectangle r1;
			if(o == orientation.HORIZONTAL)
				r1 = new Rectangle(x, y, length, 5);
			else 
				r1 = new Rectangle(x, y, 5, length);
			return r1.intersects(r2);
		}
	}
