package RPGPackage;

import java.awt.Graphics;

public class InventoryState implements IState {
	Inventory inventory = new Inventory();
	@Override
	public void Update() {
		// TODO Auto-generated method stub
	}

	@Override
	public void Render(Graphics g) {
		inventory.draw(g);
	}

	@Override
	public void OnEnter() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void OnExit() {
		// TODO Auto-generated method stub
		
	}

}
