package RPGPackage;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.LinkedList;
public class StateStack implements IState {
	LinkedList<Map> stack = new LinkedList<Map>();
	StateStack(){
	}
	public void pop() {
		stack.removeLast();
	}
	public void push(IState top, String name) {
		stack.addLast(new Map(name, top));
	}
	@Override
	public void Update() {
		stack.getLast().state.Update();
		
	}
	@Override
	public void Render(Graphics g) {
		stack.getLast().state.Render(g);
		
	}
	@Override
	public void OnEnter() {
		stack.getLast().state.OnEnter();
	}
	@Override
	public void OnExit() {
		stack.getLast().state.OnExit();
	}
	public String get() {
		return stack.getLast().name;
	}
}
class Map{
	IState state;
	String name;
	Map(String name, IState state){
		this.name = name;
		this.state = state;
	}
}
