package RPGPackage;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Inventory {
	int tileCount = 10;
	int x = 0;
	int y = 0;
	BufferedImage img[] = new BufferedImage[4];
	public Inventory() {
		try {
			img[0] = ImageIO.read(new File("inventory1.png"));
			img[1] = ImageIO.read(new File("inventory2.png"));
			img[2] = ImageIO.read(new File("inventory3.png"));
			img[3] = ImageIO.read(new File("right1.png"));
		} catch (IOException e1) 
		{
		}
	}
	public void draw(Graphics g) {
		g.drawImage(img[1],x-200,y - 100,1920,1150,null);
		g.drawImage(img[3],x+100,y+100,250,250,null);
		g.drawImage(img[0],x+50,y+150,75,75,null);
		g.drawImage(img[0],x+50,y+225,75,75,null);
		g.drawImage(img[0],x+350,y+150,75,75,null);
		g.drawImage(img[0],x+350,y+225,75,75,null);
		g.drawImage(img[0],x+175,y+30,75,75,null);
		g.drawImage(img[0],x+175,y+340,75,75,null);
		g.drawImage(img[0],x,y+750,75,75,null);
		//
		g.drawImage(img[0],x+75,y+750,75,75,null);
		g.drawImage(img[0],x+150,y+750,75,75,null);
		g.drawImage(img[0],x+225,y+750,75,75,null);
		g.drawImage(img[0],x+300,y+750,75,75,null);
		g.drawImage(img[0],x+375,y+750,75,75,null);
		g.drawImage(img[0],x+450,y+750,75,75,null);
		g.drawImage(img[0],x+525,y+750,75,75,null);
		g.drawImage(img[0],x+600,y+750,75,75,null);
		g.drawImage(img[0],x+675,y+750,75,75,null);
		g.drawImage(img[0],x+750,y+750,75,75,null);
		g.drawImage(img[0],x+825,y+750,75,75,null);
		g.drawImage(img[0],x+900,y+750,75,75,null);
		g.drawImage(img[0],x+975,y+750,75,75,null);
		g.drawImage(img[0],x+1050,y+750,75,75,null);
		g.drawImage(img[0],x+1125,y+750,75,75,null);
		g.drawImage(img[0],x+1200,y+750,75,75,null);
		g.drawImage(img[0],x+1275,y+750,75,75,null);
		g.drawImage(img[0],x+1350,y+750,75,75,null);
		g.drawImage(img[0],x+1425,y+750,75,75,null);
		g.drawImage(img[0],x+1500,y+750,75,75,null);
		g.drawImage(img[0],x+1575,y+750,75,75,null);
		g.drawImage(img[0],x+1650,y+750,75,75,null);
		//
		g.drawImage(img[0],x,y+825,75,75,null);
		g.drawImage(img[0],x+75,y+825,75,75,null);
		g.drawImage(img[0],x+150,y+825,75,75,null);
		g.drawImage(img[0],x+225,y+825,75,75,null);
		g.drawImage(img[0],x+300,y+825,75,75,null);
		g.drawImage(img[0],x+375,y+825,75,75,null);
		g.drawImage(img[0],x+450,y+825,75,75,null);
		g.drawImage(img[0],x+525,y+825,75,75,null);
		g.drawImage(img[0],x+600,y+825,75,75,null);
		g.drawImage(img[0],x+675,y+825,75,75,null);
		g.drawImage(img[0],x+750,y+825,75,75,null);
		g.drawImage(img[0],x+825,y+825,75,75,null);
		g.drawImage(img[0],x+900,y+825,75,75,null);
		g.drawImage(img[0],x+975,y+825,75,75,null);
		g.drawImage(img[0],x+1050,y+825,75,75,null);
		g.drawImage(img[0],x+1125,y+825,75,75,null);
		g.drawImage(img[0],x+1200,y+825,75,75,null);
		g.drawImage(img[0],x+1275,y+825,75,75,null);
		g.drawImage(img[0],x+1350,y+825,75,75,null);
		g.drawImage(img[0],x+1425,y+825,75,75,null);
		g.drawImage(img[0],x+1500,y+825,75,75,null);
		g.drawImage(img[0],x+1575,y+825,75,75,null);
		g.drawImage(img[0],x+1650,y+825,75,75,null);
		//
		g.drawImage(img[0], x+1000,0,500,500,null);
		//
		g.drawString("Health: " + mainCharacter.self.maxHealth, x+1050, 100);
	}
}
