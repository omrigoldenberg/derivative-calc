package RPGPackage;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JComponent;

public class canvas extends JComponent {
	mainGameState main = new mainGameState();
	InventoryState inventory = new InventoryState();
	StateStack stack = new StateStack();
	canvas(){
		stack.push(main, "main");
	}
	public void update() {
		stack.Update();
		repaint();
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		stack.Render(g);
	}
}
